package com.example.fastarchivate

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class MyTheme {
    companion object{
        fun setTheme(context: Context){

            when(MyPreferences(context).theme){
                R.id.rbAutoTheme -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                R.id.rbDarkTheme -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                R.id.rbLightTheme -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }
}