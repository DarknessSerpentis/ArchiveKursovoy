package com.example.fastarchivate.ui.test

class ArchiveUseCase {
}