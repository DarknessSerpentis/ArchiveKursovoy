package com.example.fastarchivate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class successful_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_successful)

    }
}